# 🏠 Woning Alert Amsterdam

Automatische huurwoning scanner voor Amsterdam. Scant elk uur 15 websites en toont nieuwe woningen op een GitHub Pages site.

## Live pagina

`https://JOUW-GEBRUIKERSNAAM.github.io/woning-alert`

## Bronnen

| Site | Type |
|------|------|
| Pararius | Portaal |
| Funda | Portaal |
| Huurwoningen.nl | Portaal |
| Huislijn | Portaal |
| Jaap | Portaal |
| Vesteda | Verhuurder |
| MVGM (ikwilhuren.nu) | Verhuurder |
| Fris | Makelaar |
| Eefje Voogd | Makelaar |
| Van der Linden | Makelaar |
| Eigen Haard | Corporatie |
| Ymere | Corporatie |
| Rochdale | Corporatie |
| De Key | Corporatie |
| Stadgenoot | Corporatie |

## Setup (5 minuten)

### 1. Repo aanmaken

1. Ga naar [github.com/new](https://github.com/new)
2. Naam: `woning-alert`
3. Zet op **Public** (nodig voor gratis GitHub Pages)
4. Klik **Create repository**

### 2. Bestanden uploaden

```bash
git clone https://github.com/JOUW-NAAM/woning-alert
# Kopieer alle bestanden hierin
git add .
git commit -m "eerste versie"
git push
```

### 3. GitHub Pages aanzetten

1. Ga naar je repo → **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: `main` · Folder: `/docs`
4. Klik **Save**

Na ~1 minuut is je site live op `https://JOUW-NAAM.github.io/woning-alert`

### 4. Eerste scan handmatig starten

1. Ga naar je repo → **Actions**
2. Klik **Woning Alert Scan**
3. Klik **Run workflow** → **Run workflow**
4. Wacht ~5 minuten
5. Refresh je pagina

Daarna draait de scan automatisch elk uur.

## Zoekeisen aanpassen

Pas `scraper/scrape.py` aan bovenaan:

```python
ZOEKEISEN = {
    "max_prijs":  4000,   # maximale huurprijs
    "min_kamers": 3,      # minimaal aantal slaapkamers
}
```

## Kosten

**€0** — GitHub Actions gratis tier: 2.000 minuten/maand.
Elk uur draaien = ~720 runs × ~2 min = ~1.440 minuten/maand. Ruim binnen limiet.
